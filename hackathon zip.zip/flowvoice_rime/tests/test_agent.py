import asyncio
from backend.agent import TaskAgent


def test_stale_generation_is_discarded():
    async def run():
        agent = TaskAgent()

        old_generation = agent.new_generation()
        new_generation = agent.new_generation()

        old_result = await agent.run("Start a long task.", old_generation)
        assert old_result.stale is True

        new_result = await agent.run("Give me a short answer.", new_generation)
        assert new_result.stale is False
        assert "short answer" in new_result.text.lower()

    asyncio.run(run())
