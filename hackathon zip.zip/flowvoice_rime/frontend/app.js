const $ = (id) => document.getElementById(id);

let socket = null;
let recognition = null;
let listening = false;

let audioContext = null;
let audioQueue = [];
let currentSource = null;
let audioPlaying = false;
let audioStartedAt = 0;

let currentGeneration = null;
let requestStartedAt = 0;
let interruptedCount = 0;
let staleCount = 0;

function log(message) {
  const stamp = new Date().toLocaleTimeString();
  $("log").textContent += `[${stamp}] ${message}\n`;
  $("log").scrollTop = $("log").scrollHeight;
}

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerHTML = `<div class="label">${role === "user" ? "YOU" : "FLOWVOICE"}</div><div>${escapeHtml(text)}</div>`;
  $("messages").appendChild(div);
}

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

function connect() {
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  socket = new WebSocket(`${protocol}://${location.host}/ws`);
  socket.binaryType = "arraybuffer";

  socket.onopen = () => {
    $("status").textContent = "Connected";
    $("status").className = "status online";
    log("Connected to voice agent.");
  };

  socket.onclose = () => {
    $("status").textContent = "Disconnected";
    $("status").className = "status offline";
    log("Socket disconnected.");
  };

  socket.onerror = () => log("Socket error.");

  socket.onmessage = async (event) => {
    if (event.data instanceof ArrayBuffer) {
      await enqueueAudio(event.data);
      return;
    }

    const msg = JSON.parse(event.data);
    handleEvent(msg);
  };
}

function handleEvent(msg) {
  switch (msg.type) {
    case "ready":
      log(`Rime ready: model=${msg.model}, speaker=${msg.speaker}`);
      break;

    case "request_accepted":
      currentGeneration = msg.generation_id;
      requestStartedAt = performance.now();
      $("generation").textContent = currentGeneration;
      log(`Generation ${currentGeneration} accepted.`);
      break;

    case "tts_start":
      $("orb").classList.add("speaking");
      log(`Rime TTS started for generation ${msg.generation_id}.`);
      break;

    case "tts_end":
      log(`Rime TTS completed for generation ${msg.generation_id}.`);
      break;

    case "tool_complete":
      log(`Tool completed in ${msg.elapsed_ms} ms.`);
      break;

    case "stale_discarded":
      staleCount++;
      $("stale").textContent = staleCount;
      log(`STALE RESULT DISCARDED: generation ${msg.generation_id}`);
      break;

    case "cancelled":
      log(`Cancellation: ${msg.reason}`);
      break;

    case "task_cancelled":
      log(`Task cancelled: generation ${msg.generation_id}`);
      break;

    case "error":
      log(`ERROR: ${msg.message}`);
      break;
  }
}

function sendRequest(text) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    log("Not connected.");
    return;
  }

  stopAudio();
  requestStartedAt = performance.now();

  socket.send(JSON.stringify({
    type: "request",
    text
  }));

  addMessage("user", text);
}

function interrupt(reason = "user_interrupt") {
  interruptedCount++;
  $("interrupted").textContent = interruptedCount;

  stopAudio();

  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: "cancel", reason }));
  }

  log(`INTERRUPT issued (${reason}).`);
}

async function enqueueAudio(arrayBuffer) {
  if (!audioContext) {
    audioContext = new AudioContext();
  }

  const buffer = await audioContext.decodeAudioData(arrayBuffer.slice(0));
  audioQueue.push(buffer);

  if (!audioPlaying) playNext();
}

function playNext() {
  if (audioQueue.length === 0) {
    audioPlaying = false;
    $("orb").classList.remove("speaking");
    return;
  }

  audioPlaying = true;
  const buffer = audioQueue.shift();

  currentSource = audioContext.createBufferSource();
  currentSource.buffer = buffer;
  currentSource.connect(audioContext.destination);

  if (!audioStartedAt) {
    audioStartedAt = performance.now();
    const ttfb = audioStartedAt - requestStartedAt;
    $("ttfb").textContent = `${Math.round(ttfb)} ms`;
    log(`Measured user-visible TTFB: ${Math.round(ttfb)} ms`);
  }

  currentSource.onended = () => {
    currentSource = null;
    playNext();
  };

  currentSource.start();
}

function stopAudio() {
  audioQueue = [];

  if (currentSource) {
    try { currentSource.stop(); } catch (_) {}
    currentSource.disconnect();
    currentSource = null;
  }

  audioPlaying = false;
  audioStartedAt = 0;
  $("orb").classList.remove("speaking");
}

function setupRecognition() {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    log("SpeechRecognition is unavailable. Use Chrome or Edge, or type requests in the console.");
    $("micBtn").disabled = true;
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  recognition.onstart = () => {
    listening = true;
    $("micBtn").textContent = "🎙 Listening…";
    $("orb").classList.add("listening");
  };

  recognition.onresult = (event) => {
    let finalText = "";

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const text = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalText += text;
    }

    if (finalText.trim()) {
      // A new user turn is itself an interruption of current speech.
      if (audioPlaying || currentGeneration !== null) {
        interrupt("new_user_turn");
      }

      sendRequest(finalText.trim());
    }
  };

  recognition.onerror = (event) => {
    log(`Speech recognition: ${event.error}`);
  };

  recognition.onend = () => {
    listening = false;
    $("micBtn").textContent = "🎙 Start listening";
    $("orb").classList.remove("listening");
  };
}

$("micBtn").onclick = () => {
  if (!recognition) return;
  if (listening) recognition.stop();
  else recognition.start();
};

$("interruptBtn").onclick = () => interrupt();

$("stressBtn").onclick = async () => {
  addMessage("user", "Stress test: start a long task.");
  sendRequest("Start a long task.");

  await new Promise(resolve => setTimeout(resolve, 1200));

  // Simulate a real user changing their mind while the first task is still running.
  interrupt("stress_test_interruption");

  addMessage("user", "Stop that. Give me a short answer instead.");
  sendRequest("Stop that. Give me a short answer instead.");
};

setupRecognition();
connect();
