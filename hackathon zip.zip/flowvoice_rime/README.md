# FlowVoice — Interruptible Voice Task Agent

A Rime-focused hackathon prototype for testing **interruption and recovery** in a voice-native task agent.

## What it demonstrates

1. Browser microphone → Web Speech recognition.
2. User request enters a task agent.
3. A deliberately slow tool operation runs.
4. Rime TTS speaks the response.
5. The user can interrupt at any time.
6. The current audio is stopped immediately.
7. The old generation is invalidated.
8. Late/stale tool results are discarded.
9. The replacement request becomes the only active request.
10. The UI records measurable interruption and recovery events.

This maps directly to the Rime challenge's interruption/recovery direction.

## Requirements

- Python 3.10+
- A Rime API key
- Chrome or Edge for browser speech recognition
- Internet access

## Setup

### 1. Create and activate a virtual environment

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Rime

Copy `.env.example` to `.env` and add your Rime key:

```env
RIME_API_KEY=your_key_here
RIME_MODEL=mistv3
RIME_SPEAKER=cove
RIME_LANGUAGE=en
RIME_WS_URL=wss://users-ws.rime.ai/ws3
```

Do not commit `.env`.

### 4. Start the server

```bash
python backend/app.py
```

Open:

http://127.0.0.1:8000

## Demo script

Try this exact flow:

1. Say: **"Start a long task."**
2. Wait until the agent begins speaking.
3. Click **Interrupt** or say a new request.
4. Say: **"Stop that. Give me a short answer instead."**
5. Confirm that:
   - old audio stops,
   - the old task is cancelled/invalidated,
   - a stale result is not spoken,
   - the new response is spoken by Rime.

The app also has **Run stress test**, which creates a controlled delayed-tool scenario.

## Important

The frontend never receives the Rime API key. Rime credentials stay server-side.

For the final hackathon submission, replace the demo task logic in `backend/agent.py` with your real task/tool stack and keep the generation/fencing mechanism.
