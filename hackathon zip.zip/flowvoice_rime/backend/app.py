import asyncio
import json
import os
import time
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.agent import TaskAgent
from backend.rime import synthesize, RimeError

BASE = Path(__file__).resolve().parent.parent
load_dotenv(BASE / ".env")

app = FastAPI(title="FlowVoice — Rime Interruptible Voice Agent")
agent = TaskAgent()

app.mount("/static", StaticFiles(directory=BASE / "frontend"), name="static")


@app.get("/")
async def index():
    return FileResponse(BASE / "frontend" / "index.html")


@app.get("/api/health")
async def health():
    return JSONResponse(
        {
            "ok": True,
            "rime_configured": bool(os.getenv("RIME_API_KEY")),
            "model": os.getenv("RIME_MODEL", "mistv3"),
            "speaker": os.getenv("RIME_SPEAKER", "cove"),
        }
    )


async def send_event(ws: WebSocket, event_type: str, **data):
    await ws.send_text(json.dumps({"type": event_type, **data}))


@app.websocket("/ws")
async def voice_socket(ws: WebSocket):
    await ws.accept()

    current_generation = 0
    task: asyncio.Task | None = None
    tts_task: asyncio.Task | None = None

    async def cancel_current(reason: str):
        nonlocal task, tts_task

        if task and not task.done():
            task.cancel()
        if tts_task and not tts_task.done():
            tts_task.cancel()

        await send_event(ws, "cancelled", reason=reason)

    async def speak(text: str, generation_id: int):
        try:
            await send_event(ws, "tts_start", generation_id=generation_id)

            async for chunk in synthesize(text):
                # Fencing: never send audio for an obsolete request.
                if generation_id != current_generation:
                    return

                await ws.send_bytes(chunk)

            if generation_id == current_generation:
                await send_event(
                    ws,
                    "tts_end",
                    generation_id=generation_id,
                )

        except asyncio.CancelledError:
            raise
        except RimeError as exc:
            await send_event(ws, "error", message=str(exc))
        except Exception as exc:
            await send_event(ws, "error", message=f"TTS error: {exc}")

    try:
        await send_event(
            ws,
            "ready",
            model=os.getenv("RIME_MODEL", "mistv3"),
            speaker=os.getenv("RIME_SPEAKER", "cove"),
        )

        while True:
            raw = await ws.receive_text()
            msg = json.loads(raw)
            msg_type = msg.get("type")

            if msg_type == "cancel":
                current_generation += 1
                await cancel_current(msg.get("reason", "user_interrupt"))
                continue

            if msg_type != "request":
                continue

            text = str(msg.get("text", "")).strip()
            if not text:
                continue

            # Every new user turn gets a new generation.
            current_generation += 1
            generation_id = current_generation

            await cancel_current("superseded_by_new_request")

            await send_event(
                ws,
                "request_accepted",
                generation_id=generation_id,
                text=text,
            )

            async def execute_request(gid: int, user_text: str):
                started = time.perf_counter()
                try:
                    result = await agent.run(user_text, gid)

                    if result is None or result.stale or gid != current_generation:
                        await send_event(
                            ws,
                            "stale_discarded",
                            generation_id=gid,
                        )
                        return

                    await send_event(
                        ws,
                        "tool_complete",
                        generation_id=gid,
                        elapsed_ms=round(result.elapsed_ms, 1),
                    )

                    nonlocal tts_task
                    tts_task = asyncio.create_task(speak(result.text, gid))
                    await tts_task

                except asyncio.CancelledError:
                    await send_event(ws, "task_cancelled", generation_id=gid)
                    raise
                except Exception as exc:
                    await send_event(ws, "error", message=str(exc))
                finally:
                    _ = (time.perf_counter() - started) * 1000

            task = asyncio.create_task(execute_request(generation_id, text))

    except WebSocketDisconnect:
        if task and not task.done():
            task.cancel()
        if tts_task and not tts_task.done():
            tts_task.cancel()
