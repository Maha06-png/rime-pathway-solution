import asyncio
import time
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class TaskResult:
    generation_id: int
    text: str
    elapsed_ms: float
    stale: bool = False


class TaskAgent:
    """
    Small deterministic task agent used for the hackathon demo.

    The important property is NOT the toy task itself. It is the
    generation/fencing mechanism: a result from an old request must never
    become the response to a newer request.
    """

    def __init__(self):
        self.current_generation = 0
        self.started_at: Dict[int, float] = {}

    def new_generation(self) -> int:
        self.current_generation += 1
        self.started_at[self.current_generation] = time.perf_counter()
        return self.current_generation

    def invalidate(self, generation_id: int) -> None:
        if generation_id == self.current_generation:
            self.current_generation += 1

    def is_current(self, generation_id: int) -> bool:
        return generation_id == self.current_generation

    async def run(self, text: str, generation_id: int) -> Optional[TaskResult]:
        started = self.started_at.get(generation_id, time.perf_counter())
        lowered = text.lower().strip()

        # Deliberately slow tool simulation for the stress test.
        delay = 4.0 if any(
            phrase in lowered
            for phrase in ("long task", "slow task", "check something", "start a long")
        ) else 0.7

        await asyncio.sleep(delay)

        elapsed_ms = (time.perf_counter() - started) * 1000

        # The tool completed, but another user turn may have superseded it.
        if not self.is_current(generation_id):
            return TaskResult(
                generation_id=generation_id,
                text="",
                elapsed_ms=elapsed_ms,
                stale=True,
            )

        if any(word in lowered for word in ("stop", "cancel", "interrupt")):
            answer = "Cancelled. I am ready for your next request."
        elif "short answer" in lowered:
            answer = "Sure. The short answer is: the updated request is active."
        elif "weather" in lowered:
            answer = "This demo does not call a live weather service yet. The important part is that a new request can interrupt this response safely."
        elif "meeting" in lowered:
            answer = "Your meeting task is ready. In the production version, this step would call the calendar tool."
        elif any(
            phrase in lowered
            for phrase in ("long task", "slow task", "check something", "start a long")
        ):
            answer = "The long-running task finished. This response should only be spoken if you did not interrupt it."
        else:
            answer = f"I heard: {text}. The task completed successfully."

        return TaskResult(
            generation_id=generation_id,
            text=answer,
            elapsed_ms=elapsed_ms,
            stale=False,
        )
