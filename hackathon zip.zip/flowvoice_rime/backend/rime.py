import asyncio
import base64
import json
import os
from typing import AsyncIterator

import websockets


class RimeError(RuntimeError):
    pass


def _rime_url() -> str:
    base = os.getenv("RIME_WS_URL", "wss://users-ws.rime.ai/ws3")
    model = os.getenv("RIME_MODEL", "mistv3")
    speaker = os.getenv("RIME_SPEAKER", "cove")
    language = os.getenv("RIME_LANGUAGE", "en")

    separator = "&" if "?" in base else "?"
    return (
        f"{base}{separator}"
        f"speaker={speaker}&modelId={model}&lang={language}"
        f"&audioFormat=mp3&segment=immediate"
    )


async def synthesize(text: str) -> AsyncIterator[bytes]:
    """
    Stream Rime audio chunks.

    The API key remains on the server.
    A caller can cancel the async generator; the websocket is then closed.
    """
    api_key = os.getenv("RIME_API_KEY")
    if not api_key:
        raise RimeError("RIME_API_KEY is not configured.")

    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        async with websockets.connect(
            _rime_url(),
            additional_headers=headers,
            ping_interval=20,
            ping_timeout=20,
        ) as ws:
            await ws.send(json.dumps({"text": text}))
            await ws.send(json.dumps({"operation": "eos"}))

            while True:
                raw = await ws.recv()

                if isinstance(raw, bytes):
                    yield raw
                    continue

                message = json.loads(raw)

                if message.get("type") == "chunk":
                    encoded = message.get("data")
                    if encoded:
                        yield base64.b64decode(encoded)

                if message.get("type") in {"done", "eos"}:
                    break

                if message.get("type") == "error":
                    raise RimeError(str(message))

    except asyncio.CancelledError:
        # Closing/cancelling this coroutine stops the current synthesis stream.
        raise
