# RIME_EVIDENCE

## Hard voice claim

FlowVoice prevents an interrupted voice task from continuing to speak obsolete information.

## Acceptance test

1. Start a deliberately slow task.
2. Wait until it is running.
3. Interrupt it.
4. Submit a replacement request.
5. Verify that:
   - current playback stops;
   - the old generation is invalidated;
   - an old tool result is marked stale and discarded;
   - only the replacement generation is eligible for Rime TTS;
   - the replacement response is spoken.

## Repeatable demo

Run the application and press **Run stress test**.

The test starts a long task, interrupts it after approximately 1.2 seconds, and submits a replacement request.

## Measurements

The browser records:

- user-visible TTFB;
- generation ID;
- interruption count;
- stale-result count;
- tool completion time.

## Evidence discipline

The application distinguishes:
- tool completion time,
- Rime TTS start,
- user-visible audio start,
- stale result rejection.

Do not claim that one measurement proves the entire voice pipeline is fast. For the final submission, repeat measurements across multiple runs and report the method and limitations.

## Limitations

- Browser speech recognition is used as the prototype STT layer.
- The demo task tool is deterministic and intentionally delayed.
- The final production version should use a real task/tool integration.
- Browser/device/network latency can affect measurements.
